﻿namespace $safeprojectname$.Models
{
    class MainModel
    {
    }
}
