﻿
using $safeprojectname$.Views;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;

namespace $safeprojectname$
{
    public class $safeprojectname$Module : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            //View を ContentRegion に入れる
            var regionManager = containerProvider.Resolve<IRegionManager>();
            regionManager.RegisterViewWithRegion("ContentRegion", typeof($safeprojectname$View));
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {

        }
    }
}